﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Text;
using System.Xml;
using System.IO;

namespace RSS_Feeds
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        public void GetFeed()
        {

            WebClient client = new WebClient();

            client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);

            client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/rss.xml"));

        }



        void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {

            string data = e.Result;
            StringBuilder output = new StringBuilder();
            // do something with the feed here
           
            //
            parseXml(data);

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            GetFeed();
        }

        public void parseXml(string xmlString)
        {
            StringBuilder output = new StringBuilder();
            // Create an XmlReader
            string strLink = "";


//            String xmlString =
//                @"<bookstore>
//                    <book genre='autobiography' publicationdate='1981-03-22' ISBN='1-861003-11-0'>
//                    <title>The Autobiography of Benjamin Franklin</title>
//                        <author>
//                            <first-name>Benjamin</first-name>
//                            <last-name>Franklin</last-name>
//                        </author>
//                        <price>8.99</price>
//                    </book>
//                </bookstore>";

            using (XmlReader reader = XmlReader.Create(new StringReader(xmlString)))
            {
                reader.MoveToContent();
                reader.Read();
                while (!reader.EOF)
                {
                    //reader.MoveToContent();
                    if (reader.ReadToFollowing("item"))
                    {


                        reader.ReadToFollowing("title");
                        string strTitle = reader.Value;
                        output.AppendLine("The title: " + reader.ReadElementContentAsString());
                        ////
                        reader.ReadToFollowing("link");
                        strLink = "<HyperlinkButton  " +  "TargetsName=''" + "_blank''"  + "  NavigateUri=";
                        //strLink = strLink + strLink;
                        strLink = strLink + "''" + reader.ReadElementContentAsString() + "''";
                        strLink = strLink + "  Content=" + "''Option 1''" + "/>";
                        output.AppendLine(strLink);
                        ////comments
                        //reader.ReadToFollowing("comments");
                        //output.AppendLine("The comments: " + reader.ReadElementContentAsString());
                        ////dc:creator
                        reader.ReadToFollowing("dc:creator");
                        output.AppendLine("Author: " + reader.ReadElementContentAsString());
                        ////category
                        //reader.ReadToFollowing("category");
                        //output.AppendLine("The category: " + reader.ReadElementContentAsString());
                        ////guid 
                        //reader.ReadToFollowing("guid");
                        //output.AppendLine("The guid: " + reader.ReadElementContentAsString());
                        ////description
                        //reader.ReadToFollowing("description");
                        //output.AppendLine("The description: " + reader.ReadElementContentAsString());
                        ////content:encoded
                        //reader.ReadToFollowing("content:encoded");
                        //output.AppendLine("The content:encoded: " + reader.ReadElementContentAsString());
                    }
                }

            }

            textBlock1.Text = output.ToString();
        }

    }
}