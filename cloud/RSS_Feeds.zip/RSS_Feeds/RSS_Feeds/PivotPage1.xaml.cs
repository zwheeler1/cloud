﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace RSS_Feeds
{
    public partial class PivotPage1 : PhoneApplicationPage
    {
        public PivotPage1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            GetFeed();
        }
        public void GetFeed()
        {

            WebClient client = new WebClient();

            client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);

            client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/rss.xml"));
            //  client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/News.xml"));
            //  client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/Entertainment.xml"));
            //  client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/Lifeandstyle.xml"));
            //  client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/Blogs.xml"));
            //  client.DownloadStringAsync(new Uri("http://www.blackamericaweb.com/rss/BAW/Ifyoumissedit.xml"));
        }

        void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {

            string data = e.Result;

            // do something with the feed here
           // textBlock1.Text = data;

        }
    }
}