﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Caching;

public partial class frmVariableName : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVariableNames();
          
        }
    }
    
    public void GetVariableNames()
    {
        System.Data.DataSet dsVariableName = new System.Data.DataSet();
        clsDataAccess oData = new clsDataAccess();
        string sqlSearch;
        try
        {

            if (Cache["variableName"] == null)
            {
                sqlSearch = "Select distinct physical_column_name from mf_master_ded order by physical_column_name";

                //Display in DDL
                //
                dsVariableName = oData.getDataSet(sqlSearch);
                ddlVariableName.DataSource = dsVariableName;
                ddlVariableName.DataTextField = "physical_column_name";
                ddlVariableName.DataValueField = "physical_column_name";
                ddlVariableName.DataBind();
                //

                //
                Cache.Insert("variableName", dsVariableName);
                // 
            }
            else
            {
                dsVariableName = (System.Data.DataSet)Cache["variableName"];
                //
                ddlVariableName.DataSource = dsVariableName;
                ddlVariableName.DataTextField = "physical_column_name";
                ddlVariableName.DataValueField = "physical_column_name";
                ddlVariableName.DataBind();
                //

            }
        }
        catch (Exception ex)
        {
            string strM = ex.Message;
        }
        finally
        {

        }
    }

   
    protected void ddlVariableName_SelectedIndexChanged(object sender, EventArgs e)
    {
        clsDataAccess oData = new clsDataAccess();
        string sqlSearch;

        sqlSearch = "select HUD_System_Name as 'Source',fk_table_name as 'Table Name',business_column_name as 'Business Name',physical_column_name as 'Variable Name',definition as 'Definition',data_type as 'Data Type',nulls_allowed as 'Nulls',";
        sqlSearch = sqlSearch + " Is_Primary_Key as 'PK',Is_Foreign_Key as 'FK',Is_Read_Only as 'RO'";
        sqlSearch = sqlSearch + " from mf_master_ded where physical_column_name = '" + ddlVariableName.SelectedItem.Text + "'" + " order by fk_table_name";
        grvData.DataSource = oData.getDataSet(sqlSearch);
        grvData.DataBind();
    }
   
    protected void btnClear_Click(object sender, EventArgs e)
    {

        
        ddlVariableName.SelectedIndex = -1;
        grvData.DataSource = null;
        grvData.DataBind();
    }
}