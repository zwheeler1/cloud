﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.Services;


/// <summary>
/// Summary description for clsDataAccess
/// </summary>
public class clsDataAccess
{
    public clsDataAccess()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region Connection Properties

    SqlConnection sqlConn = new SqlConnection();
    SqlCommand sqlCmd = new SqlCommand();


    #endregion

    #region Private Members
    DataSet ds = new DataSet();
    #endregion

    #region Public Methods

    public DataSet getDataSet(int intValue, string strStoredProcedureName)
    {


        if (sqlConn.State == ConnectionState.Open)
        {
            sqlConn.Close();
        }
        sqlConn.ConnectionString = ConfigurationManager.AppSettings["strConnSQL"];
        sqlConn.Open();
        sqlCmd.Connection = sqlConn;
        sqlCmd.CommandText = strStoredProcedureName;
        sqlCmd.CommandType = CommandType.StoredProcedure;
        //
        try
        {
            SqlParameter P0 = new SqlParameter();
            sqlCmd.Parameters.Add("@ParameterValue", SqlDbType.VarChar);
            P0.Direction = ParameterDirection.Input;
            P0.Value = intValue;
            //
            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(ds, "tblDataSet");
            return ds;
        }
        catch (SqlException e)
        {
            return ds;
        }
        finally
        {
        }
    }
    //
    public DataSet getDataSet(string strSearch)
    {


        if (sqlConn.State == ConnectionState.Open)
        {
            sqlConn.Close();
        }
        sqlConn.ConnectionString = ConfigurationManager.AppSettings["strConnSQL"];
        sqlConn.Open();
        sqlCmd.Connection = sqlConn;
        sqlCmd.CommandText = strSearch;
        sqlCmd.CommandType = CommandType.Text;
        //
        try
        {

            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(ds, "tblDataSet");
            return ds;
        }
        catch (SqlException e)
        {
            return ds;
        }
        finally
        {
        }


    }

    public DataSet getDataSetDM(string strSearch)
    {


        if (sqlConn.State == ConnectionState.Open)
        {
            sqlConn.Close();
        }
        sqlConn.ConnectionString = ConfigurationManager.AppSettings["strConnDM"];
        sqlConn.Open();
        sqlCmd.Connection = sqlConn;
        sqlCmd.CommandText = strSearch;
        sqlCmd.CommandType = CommandType.Text;
        //
        try
        {

            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(ds, "tblDataSet");
            return ds;
        }
        catch (SqlException e)
        {
            return ds;
        }
        finally
        {
        }


    }

}

    #endregion


