﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Caching;

public partial class Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
        }
    }
    

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        clsDataAccess oData = new clsDataAccess();
        string sqlSearch;
        sqlSearch = "select HUD_System_Name as 'Source',fk_table_name as 'Table Name',business_column_name as 'Business Name',physical_column_name as 'Variable Name',definition as 'Definition',data_type as 'Data Type',nulls_allowed as 'Nulls',";
        sqlSearch = sqlSearch + " Is_Primary_Key as 'PK',Is_Foreign_Key as 'FK',Is_Read_Only as 'RO'";
        

        sqlSearch = sqlSearch + " from mf_master_ded where definition like  '%" + txtDefintion.Text + "%'" + " order by fk_table_name";
        grvData.DataSource = oData.getDataSet(sqlSearch);
        grvData.DataBind(); 
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {

        txtDefintion.Text = "";
        grvData.DataSource=null;
        grvData.DataBind();
    }
}