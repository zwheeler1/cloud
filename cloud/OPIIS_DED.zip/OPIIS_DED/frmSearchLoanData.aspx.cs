﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmSearchLoanData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        clsDataAccess oData = new clsDataAccess();
        string strTableName = "";
        if (ddlPrimaryTables.SelectedItem.Text == "Look for Insured Loans")
        {
            strTableName = "mf_insured_loan";
        }
        if (ddlPrimaryTables.SelectedItem.Text == "Look for Non-Insured Loans")
        {
            strTableName = "mf_non_insured_loan";

        }
        if (ddlPrimaryTables.SelectedItem.Text == "Look for Hud-Held Loans")
        {
            strTableName = "mf_hud_held_loan";

        }
        if (ddlPrimaryTables.SelectedItem.Text == "Look for Direct Loans")
        {
            strTableName = "mf_direct_loan";
        }
        
        string sqlSearch = "Select * ";
       // sqlSearch = sqlSearch + "  ";
        sqlSearch = sqlSearch + " from ";
        sqlSearch = sqlSearch + strTableName ;
        if (rblSearchBy.SelectedItem.Value == "FHA Number")
        {
            sqlSearch = sqlSearch + " " + " where fk_fha_number = '" + txtSearchCriteria.Text + "'" ;
        }
        if (rblSearchBy.SelectedItem.Value == "Property Id")
        {
            sqlSearch = sqlSearch + " " + " where fk_property_id = " + txtSearchCriteria.Text;
        }
        
        sqlSearch = sqlSearch + " " + " order by pk_financing_instrument_id ";
        //
        grvData.DataSource = oData.getDataSetDM(sqlSearch);
        grvData.DataBind();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {

        txtSearchCriteria.Text = "";
        lblSearchBy.Text = "";
        lblNextStep.Text = "";
        lblNextStep1.Text = "";
        ddlPrimaryTables.SelectedIndex = -1;
        rblSearchBy.ClearSelection();
        grvData.DataSource = null;
        grvData.DataBind();
    }
    protected void rblSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblSearchBy.SelectedItem.Value == "FHA Number")
        {
            lblNextStep.Text = "Next -------------->";
            lblNextStep1.Text = "Then -------------->";
            lblSearchBy.Text = "Please Enter FHA Number";
        }
            else
        {
            lblNextStep.Text = "Next -------------->";
            lblNextStep1.Text = "Then-------------->";
            lblSearchBy.Text = "Please Enter Property ID";
        }
            
        
    }
}