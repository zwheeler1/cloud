﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Caching;

public partial class frmAttribute : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetBusinessNames();
        }
    }
    public void GetBusinessNames()
    {
        System.Data.DataSet dsBusinessName = new System.Data.DataSet();
        clsDataAccess oData = new clsDataAccess();
        string sqlSearch;
        try
        {

            if (Cache["businessName"] == null)
            {
                sqlSearch = "Select distinct business_column_name from mf_master_ded order by business_column_name";

                //Display in DDL
                //
                dsBusinessName = oData.getDataSet(sqlSearch);
                ddlAttributeName.DataSource = dsBusinessName;
                ddlAttributeName.DataTextField = "business_column_name";
                ddlAttributeName.DataValueField = "business_column_name";
                ddlAttributeName.DataBind();
                //

                //
                Cache.Insert("businessName", dsBusinessName);
                // 
            }
            else
            {
                dsBusinessName = (System.Data.DataSet)Cache["businessName"];
                //
                ddlAttributeName.DataSource = dsBusinessName;
                ddlAttributeName.DataTextField = "business_column_name";
                ddlAttributeName.DataValueField = "business_column_name";
                ddlAttributeName.DataBind();
                //

            }
        }
        catch (Exception ex)
        {
            string strM = ex.Message;
        }
        finally
        {

        }



    }
    

    protected void ddlAttributeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        clsDataAccess oData = new clsDataAccess();
        string sqlSearch;
        sqlSearch = "select HUD_System_Name as 'Source',fk_table_name as 'Table Name',business_column_name as 'Business Name',physical_column_name as 'Variable Name',definition as 'Definition',data_type as 'Data Type',nulls_allowed as 'Nulls',";
        sqlSearch = sqlSearch + " Is_Primary_Key as 'PK',Is_Foreign_Key as 'FK',Is_Read_Only as 'RO'";
        sqlSearch = sqlSearch + "from mf_master_ded where business_column_name = '" + ddlAttributeName.SelectedItem.Text + "'" + " order by fk_table_name";
       
        grvData.DataSource = oData.getDataSet(sqlSearch);
        grvData.DataBind();
    }
   
   
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlAttributeName.SelectedIndex = -1;
        grvData.DataSource = null;
        grvData.DataBind();
    }
}