﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TableDescriptions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getTableNames();
        }

    }
    public void getTableNames()
    {
        clsDataAccess oData = new clsDataAccess();
        string strSelect;
        strSelect = "Select cat_source_system as 'Source',pk_table_name as 'Table Name', tag_table_description as 'Description' from ref_table_information order by pk_table_name";
        grvTableDescriptions.DataSource = oData.getDataSet(strSelect);
        grvTableDescriptions.DataBind();
    }
}