﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace RemindMe
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            //  this.tsViewReminders.SwitchForeground = new SolidColorBrush(Colors.Red);
            //Set events for the toggle switch
            tsViewReminders.Checked += new EventHandler<RoutedEventArgs>(tsViewReminders_Checked);
            //tsViewReminders.Click += new EventHandler<RoutedEventArgs>(tsViewReminders_Click);
            //tsViewReminders.Indeterminate += new EventHandler<RoutedEventArgs>(tsViewReminders_Indeterminate);
            tsViewReminders.Unchecked += new EventHandler<RoutedEventArgs>(tsViewReminders_Unchecked);
            //
            tsSetReminder.Checked += new EventHandler<RoutedEventArgs>(tsSetReminder_Checked);
            //tsSetReminder.Click += new EventHandler<RoutedEventArgs>(tsSetReminder_Click);
            //tsSetReminder.Indeterminate += new EventHandler<RoutedEventArgs>(tsSetReminder_Indeterminate);
            tsSetReminder.Unchecked += new EventHandler<RoutedEventArgs>(tsSetReminder_Unchecked);
        }

        private void loadReminders()
        {
            IEnumerable<Reminder> Reminders = ScheduledActionService.GetActions<Reminder>();
            this.lpViewReminders.ItemsSource = Reminders;
        }

        void tsViewReminders_Checked(object sender, RoutedEventArgs e)
        {
            tsViewReminders.Content = "On";
            //var Reminders = ScheduledActionService.GetActions<Reminder>();
            ////Display Reminders
            //lpViewReminders.ItemsSource = Reminders;
            IEnumerable<Reminder> Reminders = ScheduledActionService.GetActions<Reminder>();
            this.lpViewReminders.ItemsSource = Reminders;
        }

        //void tsViewReminders_Indeterminate(object sender, RoutedEventArgs e)
        //{
        //    //Add code if toggleswitch is indeterminate state 
        //}

        void tsViewReminders_Unchecked(object sender, RoutedEventArgs e)
        {
            tsViewReminders.Content = "Off";
            //Navigate to Settings Page
            //this.NavigationService.Navigate(new Uri("/Settings.xaml", UriKind.Relative));

        }


        //Toogle Switch for Setting Page
        //void tsSetReminder_Click(object sender, RoutedEventArgs e)
        //{
        //    //Add code to execute when toggleswitch is clicked    
        //}

        void tsSetReminder_Checked(object sender, RoutedEventArgs e)
        {
            tsSetReminder.Content = "On";
            //Navigate to Settings Page
            this.NavigationService.Navigate(new Uri("/Settings.xaml", UriKind.Relative));
        }

        //void tsSetReminder_Indeterminate(object sender, RoutedEventArgs e)
        //{
        //    //Add code if toggleswitch is indeterminate state 
        //}

        void tsSetReminder_Unchecked(object sender, RoutedEventArgs e)
        {
            tsSetReminder.Content = "Off";
        }

        private void deleteReminderButton_Click(object sender, RoutedEventArgs e)
        {
            //
            string name = (string)((Button)sender).Tag;
            ScheduledActionService.Remove(name);
            loadReminders();
        }

        private void appbar_AddReminder(object sender, EventArgs e)
        {
            //Navigate to Settings Page
            this.NavigationService.Navigate(new Uri("/Settings.xaml", UriKind.Relative));

        }

        private void appbarMenu_AddReminder(object sender, EventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Settings.xaml", UriKind.Relative));
        }
        

    }
}