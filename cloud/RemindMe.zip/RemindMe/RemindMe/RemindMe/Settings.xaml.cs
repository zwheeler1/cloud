﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace RemindMe
{
    public partial class Settings : PhoneApplicationPage
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void appbar_back(object sender, EventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }


        private void appbar_save(object sender, EventArgs e)
        {
            //Create Alarm - name must be unique
            var remindername = Guid.NewGuid().ToString();
            var reminder = new Reminder(remindername);
            string strTime;
            DateTime strTimeDate;
            DateTime strDate;
            string strDateTime;
            string strReminderDateTimeCheck;
            strTimeDate = (DateTime)tpSelectTime.Value;
            strTime = strTimeDate.ToShortTimeString();
            strDate = (DateTime)dtpSelectDate.Value;
            strDateTime = strDate.ToShortDateString();
            strDateTime = strDateTime + " " + strTime;//strDate.ToShortDateString();
            //
            strReminderDateTimeCheck = (DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()).ToString();
            reminder.BeginTime = Convert.ToDateTime(strDateTime);
            if (strReminderDateTimeCheck == strDateTime)
            {
               //tblkMessage.Text = "Reminder Time must be greater that current time";
               MessageBox.Show("Reminder Time must be greater that current time");
            }
            else
            {
            reminder.Content = txtContent.Text;
            reminder.Content = txtTitle.Text;
           //NavigationUri = new Uri("/MainPage.xaml?wake=true", UriKind.RelativeOrAbsolute);
            //Add the alarm to the phone
            ScheduledActionService.Add(reminder);
            //tblkMessage.Text = "Reminder Set";

            //Vibrate to let user know that the alarm has been set
            //VibrateController.Default.Start(TimeSpan.FromMilliseconds(20));
            MessageBox.Show("Reminder Set");
            }
        }

        private void appbarMenu_save(object sender, EventArgs e)
        {
            //Create Alarm - name must be unique
            var remindername = Guid.NewGuid().ToString();
            var reminder = new Reminder(remindername);
            string strTime;
            DateTime strTimeDate;
            DateTime strDate;
            string strDateTime;
            string strReminderDateTimeCheck;
            strTimeDate = (DateTime)tpSelectTime.Value;
            strTime = strTimeDate.ToShortTimeString();
            strDate = (DateTime)dtpSelectDate.Value;
            strDateTime = strDate.ToShortDateString();
            strDateTime = strDateTime + " " + strTime;//strDate.ToShortDateString();
            //
            strReminderDateTimeCheck = (DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()).ToString();
            reminder.BeginTime = Convert.ToDateTime(strDateTime);
            if (strReminderDateTimeCheck == strDateTime)
            {
                //tblkMessage.Text = "Reminder Time must be greater that current time";
                MessageBox.Show("Reminder Time must be greater that current time");
            }
            else
            {
                reminder.Content = txtContent.Text;
                reminder.Content = txtTitle.Text;
                //NavigationUri = new Uri("/MainPage.xaml?wake=true", UriKind.RelativeOrAbsolute);
                //Add the alarm to the phone
                ScheduledActionService.Add(reminder);
                //tblkMessage.Text = "Reminder Set";

                //Vibrate to let user know that the alarm has been set
                //VibrateController.Default.Start(TimeSpan.FromMilliseconds(20));
                MessageBox.Show("Reminder Set");
            }
        }

        private void appbarMenu_back(object sender, EventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }
}