﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Data;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO.IsolatedStorage;
using System.IO;

namespace TrackMe
{
    public class clsTrackMe
    {
        #region "public"
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string DiffTime { get; set; }
        public string Distance { get; set; }
        public string finalTimeDiffNDistance { get; set; }
        #endregion

        string fileName = "TrackMeDB.txt";
        // isoStorage = IsolatedStorageFile.GetUserStoreForApplication();

        #region public methods
        public bool addNote(string finalNote)
        {
            clsTrackMe oTrack = new clsTrackMe();
            var isoStorage = IsolatedStorageFile.GetUserStoreForApplication();
            
            try
            {
                if (isoStorage.FileExists("TrackMeDB.txt"))
                {
                    using (var isoStream = new IsolatedStorageFileStream(fileName, FileMode.Append, isoStorage))
                    {
                        using (var writer = new StreamWriter(isoStream))
                        {   
                            writer.BaseStream.Seek(0, SeekOrigin.End);
                            writer.WriteLine(finalNote);
                            writer.Close();
                        }
                    }
                }
                else
                {
                    using (var file = isoStorage.OpenFile(fileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write))
                    {
                        using (var writer = new StreamWriter(file))
                        {
                            //writer.BaseStream.Seek(0, SeekOrigin.End);
                            writer.Write(finalNote);
                            writer.Close();
                        }
                    }
                }  
               
                return true;
            }
            catch (Exception ex)
            {
                string strex = ex.Message;
                return false;
            }
        }

        public string getNotes()
        {
            var isoStorage = IsolatedStorageFile.GetUserStoreForApplication();
           
           // StreamReader sr = new StreamReader(store.OpenFile(fileName, FileMode.Open, FileAccess.Read));
            string strTrackMe="";

            try
            {

               // if (isoStorage.FileExists("TrackMeDB.txt"))
                {
                    using (var isoStream = new IsolatedStorageFileStream(fileName, FileMode.Open, isoStorage))
                    {
                        using (var reader = new StreamReader(isoStream))
                        {
                            strTrackMe = reader.ReadToEnd();
                        }
                    }
                }
                return strTrackMe;
            }
            catch
            {
                return strTrackMe;
            }
        }



        public int getFileSize()
        {
            var size = 01;
            string strFile;
            var safePath = GetSafePath(fileName);
            var isoStorage = IsolatedStorageFile.GetUserStoreForApplication();
            using (var isoStream= new IsolatedStorageFileStream(fileName, FileMode.Open, isoStorage))
            {

                using (var reader = new StreamReader(isoStream))
                {
                    strFile = reader.ReadToEnd();
                    size = strFile.Length;
                }
                return size;
               // size = stream.Length;
               // Stream.Close();
            }
        }

        public static string GetSafePath(string path)
        {
            var safePath = path.TrimStart('\\', '*');
            return safePath;
        }

        public bool DeleteFile()
        {
            IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication();
            storage.DeleteFile(fileName);
            return true;
        }
        #endregion

    }
}
