﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.IO.IsolatedStorage;
using System.IO;
using System.Text;
using System.Windows.Data;


namespace TrackMe
{
    public partial class PanoramaPage1 : PhoneApplicationPage
    {
        public PanoramaPage1()
        {
            InitializeComponent();   
        }

        private void btnStartTime_Click(object sender, RoutedEventArgs e)
        {
            tbxStartTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnEndTime_Click(object sender, RoutedEventArgs e)
        {
                       
            tbxEndTime.Text = DateTime.Now.ToLongTimeString();
            TimeSpan duration = DateTime.Parse(tbxEndTime.Text).Subtract(DateTime.Parse(tbxStartTime.Text));
            tbxTimeDiff.Text = duration.ToString();
        }

        private void btnText_Click(object sender, RoutedEventArgs e)
        {
            clsTrackMe oTrack = new clsTrackMe();
            SmsComposeTask sms = new SmsComposeTask();
            sms.To = "";
            sms.Body = oTrack.getNotes();
            sms.Show();
        }

        private void btnEmail_Click(object sender, RoutedEventArgs e)
        {
            SendEmail();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (tbxStartTime.Text.Length <= 0)
            {
                MessageBox.Show("Not Saved -- Start Time Can Not Be Empty");
                return;
            }
            if (tbxEndTime.Text.Length <= 0)
            {
                MessageBox.Show("Not Saved -- End Time Can Not Be Empty");
                return;
            }
            if (tbxMilesTraveled.Text.Length <= 0)
            {
                MessageBox.Show(" Not Saved -- Distance Traveled Cannot Be Empty");
                return;
            }
            //
            string Str = tbxMilesTraveled.Text.Trim();
            double Num;
            bool isNum = double.TryParse(Str, out Num);
            if (!isNum)
            {
                MessageBox.Show("Not Saved - Invalid number for Distance");
                return;
            }

            string strTrack;
            string[] lines = new string[4];
            clsTrackMe oTrack = new clsTrackMe();
            lines[0] = tbxStartTime.Text + "  ";
            lines[1] = tbxEndTime.Text + "  ";
            lines[2] = tbxTimeDiff.Text + "  ";
            lines[3] = tbxMilesTraveled.Text + "\r\n";
            strTrack = DateTime.Now.ToShortDateString() + "\r\n" + lines[0] + lines[1] + lines[2] + lines[3];
            oTrack.finalTimeDiffNDistance = strTrack;
            //add notes to isolated storage
            if (oTrack.addNote(oTrack.finalTimeDiffNDistance))
            {
               // MessageBox.Show("Time Saved");
            }
            //
            oTrack.StartTime =tbxStartTime.Text;
            oTrack.EndTime=tbxEndTime.Text;
            oTrack.DiffTime=tbxTimeDiff.Text;
            oTrack.Distance = tbxMilesTraveled.Text;
            //
           CheckFileSize();
           tbx.Text =  oTrack.getNotes();
          // tbxFileSize.Text = oTrack.getFileSize().ToString();

        }

        protected void CheckFileSize()
        {
            string strFileSize;
            clsTrackMe oTrack = new clsTrackMe();
            strFileSize = "File Size: " + oTrack.getNotes();
            if (strFileSize.Length > 300)
            {
                MessageBox.Show("Resetting File - Sending Results to Email");
                SendEmail();
                oTrack.DeleteFile();
            }



        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            clsTrackMe oTrack = new clsTrackMe();
            oTrack.DeleteFile();
        }

        protected void SendEmail()
        {
            clsTrackMe oTrack = new clsTrackMe();
            SmsComposeTask sms = new SmsComposeTask();
            sms.To = "";
            sms.Body = oTrack.getNotes();
            sms.Show();
        }

        private void btnGetData_Click(object sender, RoutedEventArgs e)
        {
            clsTrackMe oTrack = new clsTrackMe();
            tbx.Text = oTrack.getNotes();
        }

        
    }
}